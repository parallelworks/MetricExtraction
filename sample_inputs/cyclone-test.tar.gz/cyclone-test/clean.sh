#!/bin/bash

rm -rf 100
rm -rf log*
rm -rf postProcessing
rm -rf processor*
rm -rf results
rm -rf constant/polyMesh/*
