#!/bin/bash

HOME=$PWD
source /opt/openfoam4/etc/bashrc
./run/run.sh >> execution_log.txt

# run the metric extractor
cd $HOME
chmod 777 * -R
/bin/bash mexdex/extract.sh /opt/paraview540/bin mexdex/extract.py run/system/controlDict mexdex/kpi.json results/case_$1 metrics.csv
