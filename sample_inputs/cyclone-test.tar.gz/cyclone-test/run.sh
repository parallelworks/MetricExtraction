#!/bin/bash

cd ${0%/*} || exit 1    # Run from this directory

# Source tutorial run functions
. $WM_PROJECT_DIR/bin/tools/RunFunctions

NP=$(getNumberOfProcessors)

runApplication blockMesh
runApplication decomposePar
mpirun --allow-run-as-root -np $NP snappyHexMesh -overwrite -parallel > log.snappyHexMesh

#- For non-parallel running
#cp -r 0.orig 0 > /dev/null 2>&1

#- For parallel running
ls -d processor* | xargs -I {} rm -rf ./{}/0
ls -d processor* | xargs -I {} cp -r 0.orig ./{}/0

mpirun --allow-run-as-root -np $NP patchSummary -parallel  > log.patchSummary
mpirun --allow-run-as-root -np $NP potentialFoam -parallel  > log.potentialFoam
mpirun --allow-run-as-root -np $NP $(getApplication) -parallel  > log.$(getApplication)

runApplication reconstructParMesh -constant
runApplication reconstructPar -latestTime

mkdir -p results

#xvfb-run -a --server-args="-screen 0 1024x768x24" pvpython ./scripts/streamlines.py ./run.foam ./results/streamlines.png

postProcess -func pressureDifferencePatch -field p | grep subtract | tail -1 | grep -oE "[-+]?[0-9]*\.?[0-9]+([eE][-+]?[0-9]+)?." > results/pressure_drop.txt

#------------------------------------------------------------------------------
